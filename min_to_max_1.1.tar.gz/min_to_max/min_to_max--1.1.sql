\echo Use "CREATE EXTENSION min_to_max" to load this file. \quit
create or replace function min_to_max_transition_func (arrone bigint[],b int)
/*state transition function to calculate min and max from the given set of values*/
returns bigint[] language plpgsql
as $$
declare arrtwo bigint[];
BEGIN
    arrtwo[1] = least(b::bigint,arrone[1]);
	arrtwo[2] = greatest(b::bigint,arrone[2]);
    return arrtwo;
end;
$$;
---------------------------------------------------------------------------------
create or replace function min_to_max_final_func (arrone bigint[])
/*Final function to return text string in the required format by using || operator*/
returns text language plpgsql
as $$
begin
    return arrone[1] || '-> ' || arrone[2];
end;
$$;
---------------------------------------------------------------------------------
create aggregate min_to_max (int)
/*Aggregate function to execute both state transition and final functions and to calculate state value per row*/
(
    sfunc = min_to_max_transition_func,
    finalfunc = min_to_max_final_func,
    stype = bigint[],
    initcond = '{100,-100}'
);
